import { RoutesNavegacao } from "./routes/RoutesNavegacao";

const App = () => {
  return (
    <>
      <RoutesNavegacao />
    </>
  );
}

export default App;