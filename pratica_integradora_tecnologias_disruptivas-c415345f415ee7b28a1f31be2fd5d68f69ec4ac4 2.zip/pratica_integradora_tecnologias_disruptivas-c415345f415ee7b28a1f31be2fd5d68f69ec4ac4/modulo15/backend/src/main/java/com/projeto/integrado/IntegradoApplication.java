package com.projeto.integrado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegradoApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntegradoApplication.class, args);
	}

}
